Buddy Tech — WEB EDITION
Runs on any phone and any computer. No app store, no Android needed.

WHAT'S IN THIS FOLDER
- index.html — the whole program.
- manifest.webmanifest, sw.js, icon-192.png, icon-512.png — the little
  furniture that lets a browser INSTALL the program and run it offline.

HOW TO USE IT
Put this folder on any web space (or serve it on your own network),
then open its address in a browser:
- Phone (Android, Chrome): menu -> "Add to Home screen" / "Install app".
- iPhone (Safari): Share button -> "Add to Home Screen".
- Computer (Chrome or Edge): the install icon at the right of the
  address bar puts it on your desktop like any program.
After the first open it works offline. Updates arrive on their own
the next time you open it while online.

KEEP THE FAMILY TOGETHER
Put the Buddy folders side by side in the same place (BuddyTech next to
TankMate, BatteryBuddy, SolarBuddy, WaterBuddy, BuddyBoard,
OffGridBuddy) — that's how the programs find each other in a browser.

NOTE: Buddy Tech is not linked to real hardware yet, so it shows
clearly-labelled DEMO data. Its value today is the guided diagnose
flows, the pairing/programming steps and the reference tables.
