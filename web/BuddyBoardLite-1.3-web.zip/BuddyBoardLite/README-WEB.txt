Buddy Board Lite — WEB EDITION
Part of Off Grid Buddy: the diet version of its Dash — a small
window showing the data customers need to know. It has no settings
and no options of its own; what the Off Grid Buddy shows is what
this window shows.

WHAT'S IN THIS FOLDER
- index.html — the whole window.
- manifest.webmanifest, sw.js, icon-192.png, icon-512.png — the little
  furniture that lets a browser INSTALL the program and run it offline.

HOW TO USE IT
Put this folder on any web space (or serve it on your own network),
then open its address in a browser:
- Phone (Android, Chrome): menu -> "Add to Home screen" / "Install app".
- iPhone (Safari): Share button -> "Add to Home Screen".
- Computer (Chrome or Edge): the install icon at the right of the
  address bar puts it on your desktop like any program.
After the first open it works offline.

THE MIRROR
Kept side by side with the Off Grid Buddy folder (same web space,
same browser), this window reads the Off Grid Buddy's own notebook:
its gauge choices, its colors, its figures. Change them in Off Grid
Buddy and the window wears the change. On its own it shows the
Off Grid Buddy demo figures, clearly labelled DEMO DATA — no live
link is claimed until one exists.
