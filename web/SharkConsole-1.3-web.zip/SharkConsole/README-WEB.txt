Shark Console — web copy of the console page (v1.3).
In a plain browser this shows the console window in demo form; the real
console lives in the Android app, where it talks to Shark in Termux.
